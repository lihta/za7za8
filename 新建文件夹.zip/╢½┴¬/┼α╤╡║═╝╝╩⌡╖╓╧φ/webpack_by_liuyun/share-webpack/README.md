安装node  执行下面命令安装npm 包

	cd HM-demo && npm install or cnpm install

	cd HM-more && npm install or cnpm install

执行

	 npm  run  dev 启动 开发环境 
     npm  run build 启动 编译线上环境