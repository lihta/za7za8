if (module.hot)
    module.hot.accept()
require('../css/test3.scss')
console.log('test3')