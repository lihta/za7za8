if (module.hot)
    module.hot.accept()
require('../css/test1')
require('utils')


console.log('test1...')
