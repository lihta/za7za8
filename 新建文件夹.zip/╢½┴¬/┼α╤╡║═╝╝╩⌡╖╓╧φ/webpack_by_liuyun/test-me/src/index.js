import printMe from './print.js'



var first = document.createElement('div');
document.body.appendChild(first);

var btn = document.createElement('button');
btn.innerHTML='Click me';
btn.onclick = printMe;
first.appendChild(btn)